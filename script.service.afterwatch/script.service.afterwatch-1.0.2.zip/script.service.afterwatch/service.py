# -*- coding: utf-8 -*-
import os
import xbmcgui
from resources.lib import dialog, utilfile, utilxbmc
from resources.lib.utils import setting, log
from resources.lib.progress import Progress
from resources.lib.movie import Movie
from resources.lib.episode import Episode
from resources.lib.debug import debug

## MONITOR
class AfterWatchMonitor(xbmc.Monitor):
    def __init__(self, *args, **kwargs):
        xbmc.Monitor.__init__(self)
        debug.set()

    def onSettingsChanged(self):
        log("AfterWatchMonitor.onSettingsChanged: called")
        debug.set()

## PLAYER
class AfterWatchPlayer(xbmc.Player):
    def onPlayBackStarted(self):
        log("AfterWatchPlayer.onPlayBackStarted: start")
        self.playing = None
        try:
            j = utilxbmc.xjson('{"jsonrpc":"2.0","method":"Player.GetActivePlayers","id":1}')
            t = j['result'][0]['type']
            i = j['result'][0]['playerid']
            log("onPlayBackStarted: t=%s, i=%s" % (t, i))
            if t == 'video':
                j = utilxbmc.xjson('{"jsonrpc":"2.0","method":"Player.GetItem","params":{"playerid":%s},"id":1}' % i)
                type = j['result']['item']['type']
                log("onPlayBackStarted: type=%s" % type)
                if type == 'movie':
                    self.playing = Movie()
                    self.__time()
                elif type == 'episode':
                    self.playing = Episode()
                    self.__time()
        except Exception as e:
            if debug.get():
                log(debug.traceback.print_exc(), xbmc.LOGERROR)
            debug.exception_dialog(e)
            self.playing = None
        log("AfterWatchPlayer.onPlayBackStarted: end")

    def onPlayBackEnded(self):
        log("AfterWatchPlayer.onPlayBackEnded: start")
        try:
            if hasattr(self, 'playing') and self.playing:
                log("AfterWatchPlayer.onPlayBackEnded: self.playing.ended() start")
                self.playing.ended()
                log("AfterWatchPlayer.onPlayBackEnded: self.playing.ended() end")
                self.playing = None
        except Exception as e:
            if debug.get():
                log(debug.traceback.print_exc(), xbmc.LOGERROR)
            debug.exception_dialog(e)
        finally:
            self.playing = None
        log("AfterWatchPlayer.onPlayBackEnded: end")

    def onPlayBackStopped(self):
        log("AfterWatchPlayer.onPlayBackStopped: start")
        try:
            if hasattr(self, 'playing') and self.playing:
                minimum = float(setting('assume'))
                if hasattr(self, 'time') and self.total_time > 0 and hasattr(self, 'current') and self.current > 0:
                    percent = self.current * 100 / self.total_time
                else:
                    percent = 100 # assume end of file
                if minimum <= percent:
                    self.playing.ended()
                log("AfterWatchPlayer.onPlayBackStopped: percent=%d, self.total_time=%d, self.current=%d" % (percent, self.total_time, self.current))
                self.playing = None
        except Exception as e:
            if debug.get():
                log(debug.traceback.print_exc(), xbmc.LOGERROR)
            debug.exception_dialog(e)
        finally:
            self.playing = None
        log("AfterWatchPlayer.onPlayBackStopped: end")

    def __time(self):
        log("AfterWatchPlayer.__time: start")
        try:
            self.current = self.getTime()
            self.total_time = self.getTotalTime()
            if not int(setting('assume')) == 100:
                while self.isPlaying():
                    if self.total_time == 0:
                        self.total_time = self.getTotalTime()
                    self.current = self.getTime()
                    monitor.waitForAbort(5)
            log("AfterWatchPlayer.__time: self.current=%d, self.total_time=%d" % (self.current, self.total_time))
        except Exception as e:
            if debug.get():
                log(debug.traceback.print_exc(), xbmc.LOGERROR)
            debug.exception_dialog(e)
        log("AfterWatchPlayer.__time: end")

monitor = AfterWatchMonitor()
player = AfterWatchPlayer()
log("started")
monitor.waitForAbort()
log("stopped")
