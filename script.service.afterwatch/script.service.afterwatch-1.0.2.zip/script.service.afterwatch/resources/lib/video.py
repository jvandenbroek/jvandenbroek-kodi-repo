# -*- coding: utf-8 -*-
import os
import sys
from utils import log
## TYPES
class Video:
    def show_quit_menu(self):
        xbmc.executebuiltin('ActivateWindow(shutdownmenu)')

    def logoff_user(self):
        xbmc.executebuiltin('System.LogOff')

    def turn_display_off(self):
        if not hasattr(self, 'player') or not player.isPlaying():
            if sys.platform.startswith('win'):
                path = xbmc.translatePath('special://home/addons/script.afterwatch/resources/lib/Sleeper.exe')
                os.startfile(path)
            elif sys.platform.startswith('linux'):
                path = "/usr/bin/cec-client"
                cec = os.path.isfile(path)
                if not cec:
                    path = "/usr/local/bin/cec-client"
                    cec = os.path.isfile(path)
                if cec:
                    os.system("echo standby 0 | %s -s -d 1" % path)
                else:
                    log("Video.turn_display_off: could not find cec-client")
