# -*- coding: utf-8 -*-
#import xbmc
import xbmcgui
from resources.lib.utils import info, lang, setting
from utils import log

def proceed(title, subtitle, autoclose=0):
    proceed = True
    if setting('confirm') == 'true':
        proceed = xbmcgui.Dialog().yesno(info('name'), title, lang(30526) % subtitle, None, None, None, autoclose)
    return proceed

def warning(module, count):
    proceed = True
    threshold = int(setting('fm_warn'))
    if count > threshold:
        proceed = xbmcgui.Dialog().yesno(info('name'), lang(30588) % (module, count))
    return proceed

def error(msg):
#	log(str(msg), xbmc.LOGERROR)
    xbmcgui.Dialog().ok(info('name'), str(msg))

def notification(msg):
    xbmc.executebuiltin('Notification(%s,%s,5000,%s)' % (info('name'), msg, info('icon')))
    # todo xbmcgui.Dialog().notification('Movie Trailers', 'Finding Nemo download finished.', xbmcgui.NOTIFICATION_INFO, 5000)

def rating(title):
    l = ['10 **********','9 *********','8 ********','7 *******','6 ******','5 *****','4 ****','3 ***','2 **','1 *']
    i = xbmcgui.Dialog().select(lang(30512) % (info('name'), title), l)
    if not i == -1:
        rating = 10 - i
        return rating
